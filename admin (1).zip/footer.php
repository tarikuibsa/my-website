<footer>
  <p>&copy; <?php echo date("Y"); ?> Tariku Ibsa | All rights reserved.</p>
  <div class="social-icons">
    <a href="https://www.facebook.com/sagn.ibsa" target="_blank"><i class="fab fa-facebook"></i></a>
    <a href="https://t.me/ff12g" target="_blank"><i class="fab fa-telegram"></i></a>
    <a href="http://www.youtube.com/@TarikuIbsa" target="_blank"><i class="fab fa-youtube"></i></a>
    <a href="https://tiktok.com/@enyuma1" target="_blank"><i class="fab fa-tiktok"></i></a>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
