<?php
include('db.php');
$sql = "SELECT * FROM posts ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>
<?php include('header.php'); ?>

<style>
  .blog-section {
    padding: 80px 0;
    margin-top: 100px;
    background: rgba(0, 0, 0, 0.7);
    border-radius: 20px;
  }

  .blog-title {
    color: #f1f1f1;
    text-align: center;
    margin-bottom: 40px;
    font-size: 2.5rem;
    font-weight: 600;
  }

  .blog-card {
    background-color: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 15px;
    padding: 25px;
    margin-bottom: 25px;
    color: #fff;
    transition: all 0.3s ease-in-out;
  }

  .blog-card:hover {
    background-color: rgba(255, 255, 255, 0.1);
    transform: translateY(-5px);
  }

  .blog-card h3 {
    color: #fff;
    font-size: 1.5rem;
    margin-bottom: 10px;
  }

  .blog-card small {
    color: #ccc;
  }

  .blog-card p {
    color: #ddd;
    line-height: 1.6;
  }

  .footer {
    background-color: rgba(0, 0, 0, 0.85);
    padding: 30px 0;
    text-align: center;
    margin-top: 60px;
    color: white;
  }

  .footer .social-icons a {
    color: white;
    margin: 0 10px;
    font-size: 1.4rem;
    transition: 0.3s;
  }

  .footer .social-icons a:hover {
    color: #0d6efd;
  }
</style>

<div class="container blog-section">
  <h1 class="blog-title">📰 My Blog Posts</h1>

  <?php if (mysqli_num_rows($result) > 0): ?>
    <?php while ($post = mysqli_fetch_assoc($result)): ?>
      <div class="blog-card">
        <h3><?= htmlspecialchars($post['title']) ?></h3>
        <small>Posted on <?= date('F j, Y, g:i a', strtotime($post['created_at'])) ?></small>
        <p class="mt-3"><?= nl2br(htmlspecialchars($post['content'])) ?></p>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <div class="alert alert-light text-center">No posts available yet. Please check back later!</div>
  <?php endif; ?>
</div>

<!-- Footer -->
<footer class="footer">
  <div class="container">
    <p>© <?= date('Y') ?> Tariku Ibsa | <a href="contact.php" class="text-light">Contact Me</a></p>
    <div class="social-icons mt-3">
      <a href="https://www.facebook.com/sagn.ibsa" target="_blank"><i class="fab fa-facebook"></i></a>
      <a href="https://t.me/ff12g" target="_blank"><i class="fab fa-telegram"></i></a>
      <a href="http://www.youtube.com/@TarikuIbsa" target="_blank"><i class="fab fa-youtube"></i></a>
      <a href="https://tiktok.com/@enyuma1" target="_blank"><i class="fab fa-tiktok"></i></a>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
