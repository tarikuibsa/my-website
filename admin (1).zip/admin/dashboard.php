<?php
// Fetch posts
include('../db.php');

$sql = "SELECT * FROM posts ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<h2>Posts Management</h2>
<a href="add_post.php"><strong > add post</strong></a>
<table class="table">
  <thead>
    <tr>
      <th>Title</th>
      <th>Created At</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
  <?php while($post = mysqli_fetch_assoc($result)): ?>
    <tr>
      <td><?= htmlspecialchars($post['title']) ?></td>
      <td><?= $post['created_at'] ?></td>
      <td>
        <a href="edit_post.php?id=<?= $post['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
        <a href="delete_post.php?id=<?= $post['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete this post?');">Delete</a>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
