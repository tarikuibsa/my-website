<?php
include('../db.php');

if (!isset($_GET['id'])) {
    header('Location: dashboard.php');
    exit;
}

$id = intval($_GET['id']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);

    $update_sql = "UPDATE posts SET title='$title', content='$content' WHERE id=$id";
    if (mysqli_query($conn, $update_sql)) {
        header('Location: dashboard.php?msg=Post updated successfully');
    } else {
        $error = "Error updating post: " . mysqli_error($conn);
    }
} else {
    $sql = "SELECT * FROM posts WHERE id=$id";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {
        $post = mysqli_fetch_assoc($result);
    } else {
        header('Location: dashboard.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Post</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="container my-5">
    <h2>Edit Post</h2>

    <?php if(isset($error)) echo '<div class="alert alert-danger">'.$error.'</div>'; ?>

    <form method="post" action="">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required value="<?= htmlspecialchars($post['title']) ?>">
        </div>
        <div class="mb-3">
            <label>Content</label>
            <textarea name="content" class="form-control" rows="6" required><?= htmlspecialchars($post['content']) ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update Post</button>
        <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
    </form>
    <a href="dashboard.php"></a>
</body>
</html>
