<?php
include('../db.php');

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $delete_sql = "DELETE FROM posts WHERE id=$id";
    if (mysqli_query($conn, $delete_sql)) {
        header('Location: dashboard.php?msg=Post deleted successfully');
    } else {
        header('Location: dashboard.php?error=Error deleting post');
    }
} else {
    header('Location: dashboard.php');
}
exit;
?>
