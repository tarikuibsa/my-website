<?php
include 'header.php';
include 'db.php';

$query = isset($_GET['query']) ? trim($_GET['query']) : '';

?>

<div class="container my-5" style="color: white;">
  <h2>Search Results for "<?php echo htmlspecialchars($query); ?>"</h2>

  <?php
  if ($query === '') {
      echo "<p>Please enter a search term.</p>";
  } else {
      // Prepare statement to search posts by title or content
      $sql = "SELECT * FROM posts WHERE title LIKE ? OR content LIKE ? ORDER BY created_at DESC";
      $stmt = $conn->prepare($sql);
      $searchTerm = "%$query%";
      $stmt->bind_param("ss", $searchTerm, $searchTerm);
      $stmt->execute();
      $result = $stmt->get_result();

      if ($result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo '<div class="mb-4 p-3 bg-dark rounded">';
              echo '<h3>' . htmlspecialchars($row['title']) . '</h3>';
              echo '<p>' . nl2br(htmlspecialchars(substr($row['content'], 0, 200))) . '...</p>';
              echo '</div>';
          }
      } else {
          echo "<p>No posts found.</p>";
      }
      $stmt->close();
  }
  ?>
</div>

<?php include 'footer.php'; ?>
