<?php
include('db.php');
$result = mysqli_query($conn, "SELECT * FROM uploads ORDER BY uploaded_at DESC");
?>

<h2>Uploaded Files</h2>
<table border="1" cellpadding="10">
  <tr><th>User</th><th>File</th><th>Date</th></tr>
  <?php while ($row = mysqli_fetch_assoc($result)): ?>
    <tr>
      <td><?= htmlspecialchars($row['username']) ?></td>
      <td><a href="uploads/<?= $row['filename'] ?>" target="_blank"><?= $row['filename'] ?></a></td>
      <td><?= $row['uploaded_at'] ?></td>
    </tr>
  <?php endwhile; ?>
</table>
