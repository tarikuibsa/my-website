-- Create the database
CREATE DATABASE IF NOT EXISTS yes;
USE yes;

-- Admin users table
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL -- Hashed passwords recommended
);

-- Insert default admin (username: admin, password: admin123)
INSERT INTO admins (username, password)
VALUES ('admin', '$2y$10$NLc3VkRxf1T8yfbQh9R5GuDprCvzRlg8ZDVIGnAVr0IEzLOqEPUtq'); 
-- password: admin123 (hashed using password_hash)

-- Blog posts table
CREATE TABLE IF NOT EXISTS posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contact messages table
CREATE TABLE IF NOT EXISTS contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  message TEXT NOT NULL,
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
