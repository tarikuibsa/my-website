<?php include 'header.php'; ?>
<div class="container my-5">
  <h2>Upload a File</h2>
  <form action="upload_process.php" method="POST" enctype="multipart/form-data">
    <div class="mb-3">
      <label for="username" class="form-label">Your Name:</label>
      <input type="text" name="username" class="form-control" required>
    </div>
    <div class="mb-3">
      <label for="file" class="form-label">Choose File:</label>
      <input type="file" name="file" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Upload</button>
  </form>
</div>
<?php include 'footer.php'; ?>
