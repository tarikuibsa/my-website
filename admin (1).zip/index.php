<?php
include 'header.php';

date_default_timezone_set('Africa/Addis_Ababa');
$hour = (int) date('H');

if ($hour >= 5 && $hour < 12) {
    $greeting = "Good morning 🌅";
} elseif ($hour >= 12 && $hour < 17) {
    $greeting = "Good afternoon ☀️";
} elseif ($hour >= 17 && $hour < 20) {
    $greeting = "Good evening 🌇";
} else {
    $greeting = "Good night ";
}
?>

<div class="container my-5">
  <div style="background: rgba(0, 0, 0, 0.65); padding: 30px; border-radius: 10px; color: #fff;">

    <h1 class="mb-3"><?php echo $greeting; ?></h1>
    <p>Welcome to My Personal Website!</p>

    <section class="mt-5">
      <h2>About the Developer</h2>
      <p>
        Hello! My name is <strong>Tariku Ibsa</strong>. I am currently a dedicated student at <strong>Kotebe University of Education</strong> in Ethiopia.  
        Passionate about learning and sharing knowledge, I created this website as a personal platform to express my thoughts, share educational
         content, and connect with like-minded people.
      </p>
      <p>
        I am continuously improving my skills in web development using technologies such as PHP, CSS, JavaScript, and Bootstrap.  
        This site reflects my journey and commitment to growth as a developer and a learner.
      </p>
    </section>

    <section class="mt-5">
      <h2>Purpose and Uses of This Website</h2>
      <p>
        This website serves multiple purposes, including:
      </p>
      <ul>
        <li><strong>Namoota website dhunfaa kessanii hojjechifachuu barabaaadan:</strong> karaa tora website kootii naa qunnamuu dandessu.</li>
        <li><strong>Tajajila website kana kodi website wajjin wal qabatuus:</strong> Tajaajilota website waliin wal-qabatan argachuu dandessuu
        .</li>
        <li><strong>dhimmaa kessanif:</strong> kessan naa qunamaa</li>
        <li><strong>Community Engagement:</strong> Social media links are provided for you to follow and interact with me across various platforms.</li>
      </ul>
      <p>
        Overall, this site is designed to be a welcoming and informative space where I can share knowledge, build connections, and grow as a developer.
      </p>
    </section>

  </div>
</div>

<?php include 'footer.php'; ?>
