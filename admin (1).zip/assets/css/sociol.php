 </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a href="index.php" class="nav-link <?php echo ($activePage == 'index.php') ? 'active' : ''; ?>">🏠 Home</a></li>
        <li class="nav-item"><a href="blogs.php" class="nav-link <?php echo ($activePage == 'blogs.php') ? 'active' : ''; ?>">📝 Blog</a></li>
        <li class="nav-item"><a href="contact.php" class="nav-link <?php echo ($activePage == 'contact.php') ? 'active' : ''; ?>">📬 Contact</a></li>
        <li class="nav-item"><a href="https://www.facebook.com/sagn.ibsa" class="nav-link" target="_blank">👍 <i class="fab fa-facebook"></i></a></li>
        <li class="nav-item"><a href="https://t.me/ff12g" class="nav-link" target="_blank"><i class="fab fa-telegram"></i></a></li>
        <li class="nav-item"><a href="http://www.youtube.com/@TarikuIbsa" class="nav-link" target="_blank">▶️ <i class="fab fa-youtube"></i></a></li>
        <li class="nav-item"><a href="https://tiktok.com/@enyuma1" class="nav-link" target="_blank"><i class="fab fa-tiktok"></i></a></li>
      </ul>
    </div>
  </div>
</nav>
