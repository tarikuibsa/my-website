<?php
$host = 'localhost';
$user = 'root';
$pass = ''; // Leave blank if you're using XAMPP with default settings
$db   = 'yes'; // Your confirmed database name

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("❌ Connection failed: " . mysqli_connect_error());
} else {
    // Comment this line out in production
    // echo "✅ Connected successfully!";
}
?>
