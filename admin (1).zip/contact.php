<?php
include 'header.php';
include 'db.php';

$name = $email = $message = "";
$name_err = $email_err = $message_err = "";
$success_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["name"]))) {
        $name_err = "Please enter your name.";
    } else {
        $name = htmlspecialchars(trim($_POST["name"]));
    }

    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } elseif (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
        $email_err = "Invalid email format.";
    } else {
        $email = htmlspecialchars(trim($_POST["email"]));
    }

    if (empty(trim($_POST["message"]))) {
        $message_err = "Please enter your message.";
    } else {
        $message = htmlspecialchars(trim($_POST["message"]));
    }

    if (empty($name_err) && empty($email_err) && empty($message_err)) {
        $sql = "INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sss", $name, $email, $message);
            if ($stmt->execute()) {
                $success_msg = "Thank you for contacting us!";
                $name = $email = $message = "";
            }
            $stmt->close();
        }
    }
}
?>

<style>
  .contact-container {
    max-width: 600px;
    margin: 40px auto;
    background-color: #1c1c1c;
    padding: 30px;
    border-radius: 10px;
    color: #fff;
  }
  .contact-container h2 {
    margin-bottom: 25px;
    text-align: center;
  }
  .form-label {
    color: #ccc;
  }
  input.form-control,
  textarea.form-control {
    background-color: #333 !important;
    color: #fff !important;
    border: 1px solid #555 !important;
    border-radius: 5px;
  }
  input.form-control::placeholder,
  textarea.form-control::placeholder {
    color: #999 !important;
  }
  .btn-primary {
    background-color: #0069d9;
    border-color: #0062cc;
  }
  .btn-primary:hover {
    background-color: #004a99;
    border-color: #003d80;
  }
  .alert-success {
    background-color: #2a7a2a;
    border-color: #1d4d1d;
    color: white;
  }
</style>

<div class="contact-container">
  <h2>Contact Me</h2>

  <?php if ($success_msg): ?>
    <div class="alert alert-success"><?php echo $success_msg; ?></div>
  <?php endif; ?>

  <form method="POST" action="contact.php" novalidate>
    <div class="mb-3">
      <label for="name" class="form-label">Your Name:</label>
      <input type="text" id="name" name="name" 
             class="form-control <?php echo ($name_err) ? 'is-invalid' : ''; ?>" 
             value="<?php echo $name; ?>" placeholder="Enter your name" required>
      <div class="invalid-feedback"><?php echo $name_err; ?></div>
    </div>

    <div class="mb-3">
      <label for="email" class="form-label">Your Email:</label>
      <input type="email" id="email" name="email" 
             class="form-control <?php echo ($email_err) ? 'is-invalid' : ''; ?>" 
             value="<?php echo $email; ?>" placeholder="Enter your email" required>
      <div class="invalid-feedback"><?php echo $email_err; ?></div>
    </div>

    <div class="mb-3">
      <label for="message" class="form-label">Your Message:</label>
      <textarea id="message" name="message" rows="5" 
                class="form-control <?php echo ($message_err) ? 'is-invalid' : ''; ?>" 
                placeholder="Write your message here..." required><?php echo $message; ?></textarea>
      <div class="invalid-feedback"><?php echo $message_err; ?></div>
    </div>

    <button type="submit" class="btn btn-primary w-100">Send Message</button>
  </form>
</div>

<?php include 'footer.php'; ?>
