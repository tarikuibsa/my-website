<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $uploadDir = "uploads/";

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $fileName = basename($_FILES["file"]["name"]);
    $targetFile = $uploadDir . time() . "_" . $fileName;
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Allow only specific file types
    $allowedTypes = ['jpg', 'jpeg', 'png', 'pdf', 'docx', 'txt'];

    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
            echo "<p style='color: green;'>File uploaded successfully by <strong>$username</strong>!</p>";
        } else {
            echo "<p style='color: red;'>Sorry, there was an error uploading your file.</p>";
        }
    } else {
        echo "<p style='color: red;'>Invalid file type. Allowed types: jpg, png, pdf, docx, txt.</p>";
    }
} else {
    echo "<p style='color: red;'>No file submitted.</p>";
}
?>
<a href="upload.php">⬅ Back</a>
