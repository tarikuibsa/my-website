<?php $activePage = basename($_SERVER['PHP_SELF']); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>MySite 🏠 - Tariku Ibsa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    body {
      background: url('background.jpg') no-repeat center center fixed;
      background-size: cover;
      color: white;
    }
    .navbar {
      background-color: rgba(0, 0, 0, 0.7);
    }
    .navbar-brand img {
      height: 50px;
      width: 60px;
      border-radius: 50%;
      object-fit: cover;
      margin-right: 10px;
    }
    .hero {
      text-align: center;
      padding: 100px 20px;
      background-color: rgba(0, 0, 0, 0.6);
      margin-top: 50px;
    }
    footer {
      background-color: rgba(0, 0, 0, 0.85);
      padding: 20px 0;
      text-align: center;
      margin-top: 40px;
    }
    .social-icons a {
      color: white;
      font-size: 2.2rem;
      margin: 0 10px;
    }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="admin/login.php">
      <img src="assets/images/tariku.jpg" alt="Tariku Ibsa Photo">
      MySite 
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto"> 
        <li class="nav-item"><a href="index.php" class="nav-link <?php echo ($activePage == 'index.php') ? 'active' : ''; ?>">🏠 Home</a></li>
        <li class="nav-item"><a href="blogs.php" class="nav-link <?php echo ($activePage == 'blogs.php') ? 'active' : ''; ?>">📝 Blog</a></li>
        <li class="nav-item"><a href="contact.php" class="nav-link <?php echo ($activePage == 'contact.php') ? 'active' : ''; ?>">📬 Contact</a></li>
        <li class="nav-item"><a href="https://www.facebook.com/sagn.ibsa" class="nav-link" target="_blank"><i class="fab fa-facebook"></i></a></li>
        <li class="nav-item"><a href="https://t.me/ff12g" class="nav-link" target="_blank"> <i class="fab fa-telegram"></i></a></li>
        <li class="nav-item"><a href="http://www.youtube.com/@TarikuIbsa" class="nav-link" target="_blank"><i class="fab fa-youtube"></i></a></li>
        <li class="nav-item"><a href="https://tiktok.com/@enyuma1" class="nav-link" target="_blank"> <i class="fab fa-tiktok"></i></a></li>
      </ul>
    </div>
  </div>
</nav>
